# MajaCall Android (Kotlin)

A simple Bangla + English fake incoming-call prank app. It simulates an incoming call inside the app; it does not place real calls or access contacts.

## Build an APK
1. Install Android Studio on a computer.
2. Choose **Open** and select this project folder.
3. Let Gradle sync. If prompted, use Android Gradle Plugin 8.6.1 and Gradle 8.7.
4. Connect an Android phone or use an emulator, then press Run.
5. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The project uses Android Gradle Plugin 8.6.1 and Kotlin 2.0.21. A local Android SDK/Gradle build environment is needed to compile the APK.
