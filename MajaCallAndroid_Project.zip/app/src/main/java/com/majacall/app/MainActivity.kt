package com.majacall.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 11, 37)
    private val purple = Color.rgb(111, 55, 245)
    private val cyan = Color.rgb(31, 218, 236)
    private var bangla = true
    private var timer: CountDownTimer? = null
    private lateinit var root: LinearLayout
    private lateinit var nameInput: EditText
    private lateinit var delayInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun shape(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(12, 10, 12, 10)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE)
            background = shape(purple, 32f)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 18, 22, 20)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(bg, Color.rgb(20, 13, 64), Color.rgb(5, 22, 50)))
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        root.addView(text(title, 30f, cyan, true))
    }

    private fun showHome() {
        setup("☎ MajaCall")
        root.addView(text(if (bangla) "Fake Call • শুধু মজার জন্য" else "Fake Call • Just for fun", 16f))
        val lang = button(if (bangla) "বাংলা  |  EN" else "EN  |  বাংলা") {
            bangla = !bangla; showHome()
        }
        root.addView(lang, matchWrap())
        root.addView(text(if (bangla) "বন্ধুকে একটু বোকা বানা 😄" else "Give your friend a little surprise 😄", 18f, Color.WHITE, true))

        nameInput = EditText(this).apply {
            hint = if (bangla) "Caller name (যেমন: Best Friend)" else "Caller name"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            textSize = 17f; setPadding(18, 14, 18, 14)
            background = shape(Color.rgb(28, 34, 75), 18f)
            setSingleLine(true)
        }
        root.addView(nameInput, matchWrap(14))

        delayInput = EditText(this).apply {
            hint = if (bangla) "কত সেকেন্ড পরে? (যেমন 10)" else "Delay in seconds (e.g. 10)"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            textSize = 17f; inputType = 2; setPadding(18, 14, 18, 14)
            background = shape(Color.rgb(28, 34, 75), 18f)
            setSingleLine(true); setText("10")
        }
        root.addView(delayInput, matchWrap(12))
        root.addView(button(if (bangla) "📞 Fake Call তৈরি কর" else "📞 Create Fake Call") {
            val caller = nameInput.text.toString().trim().ifEmpty { "Mystery Buddy" }
            val seconds = delayInput.text.toString().toLongOrNull()?.coerceIn(0, 300) ?: 10L
            AlertDialog.Builder(this)
                .setTitle(if (bangla) "Ready তো?" else "Ready?")
                .setMessage(if (bangla) "$caller-এর fake call $seconds সেকেন্ড পরে দেখাব?" else "Show a fake call from $caller in $seconds seconds?")
                .setNegativeButton(if (bangla) "না" else "Cancel", null)
                .setPositiveButton(if (bangla) "চালু কর" else "Start") { _, _ ->
                    showCountdown(caller, seconds)
                }.show()
        }, matchWrap(22))
        root.addView(text(if (bangla) "ফিচার" else "Features", 22f, cyan, true))
        root.addView(text("• Custom caller name\n• 0–300 sec timer\n• Answer / Decline screen\n• Bangla + English\n• No real calls, no contacts access", 15f))
        root.addView(text(if (bangla) "বন্ধুদের সাথে মজা কর, কিন্তু পরে prank বলে দিস 😉" else "Have fun, then reveal the prank 😉", 14f, Color.LTGRAY))
    }

    private fun showCountdown(caller: String, seconds: Long) {
        setup(if (bangla) "Prank Ready 😎" else "Prank Ready 😎")
        val status = text("", 20f, cyan, true)
        root.addView(status, matchWrap())
        root.addView(button(if (bangla) "এখনই Fake Call দেখাও" else "Show Fake Call Now") {
            timer?.cancel(); showIncoming(caller)
        }, matchWrap(18))
        root.addView(button(if (bangla) "Cancel" else "Cancel") { timer?.cancel(); showHome() }, matchWrap(10))
        if (seconds == 0L) showIncoming(caller) else {
            timer = object : CountDownTimer(seconds * 1000, 1000) {
                override fun onTick(ms: Long) {
                    status.text = if (bangla) "${ms / 1000 + 1} সেকেন্ড বাকি…" else "${ms / 1000 + 1} seconds left…"
                }
                override fun onFinish() { showIncoming(caller) }
            }.start()
        }
    }

    private fun showIncoming(caller: String) {
        setup(if (bangla) "Incoming Call…" else "Incoming Call…")
        root.addView(text("🙂", 76f))
        root.addView(text(caller, 30f, Color.WHITE, true))
        root.addView(text("FAKE CALL • PRANK MODE", 15f, cyan, true))
        root.addView(text(if (bangla) "এটি একটি simulated call" else "This is a simulated call", 14f, Color.LTGRAY))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        }
        val answer = Button(this).apply {
            text = if (bangla) "📞 ধর" else "📞 Answer"
            setTextColor(Color.WHITE); isAllCaps = false
            background = shape(Color.rgb(25, 190, 104), 36f)
            setOnClickListener { showAnswered(caller) }
        }
        val decline = Button(this).apply {
            text = if (bangla) "✖ কেটে দে" else "✖ Decline"
            setTextColor(Color.WHITE); isAllCaps = false
            background = shape(Color.rgb(230, 57, 70), 36f)
            setOnClickListener { showHome() }
        }
        row.addView(answer, LinearLayout.LayoutParams(0, 64, 1f).apply { setMargins(4, 8, 8, 8) })
        row.addView(decline, LinearLayout.LayoutParams(0, 64, 1f).apply { setMargins(8, 8, 4, 8) })
        root.addView(row, matchWrap(24))
    }

    private fun showAnswered(caller: String) {
        setup(if (bangla) "Call Connected 😆" else "Call Connected 😆")
        root.addView(text("😂", 70f))
        root.addView(text(caller, 26f, cyan, true))
        root.addView(text(if (bangla) "ধরা খাইছস! এটা Fake Call ছিল 🤣" else "Gotcha! This was a fake call 🤣", 20f, Color.WHITE, true))
        root.addView(text(if (bangla) "এখানে কোনো real audio call হয় না।" else "No real audio call is happening.", 14f, Color.LTGRAY))
        root.addView(button(if (bangla) "Home-এ ফিরে যা" else "Back to Home") { showHome() }, matchWrap(20))
    }

    private fun matchWrap(top: Int = 8): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = top
        }
}
